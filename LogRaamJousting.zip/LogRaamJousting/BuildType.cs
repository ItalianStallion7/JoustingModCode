﻿using System;

namespace LogRaamJousting
{
	// Token: 0x0200000B RID: 11
	public enum BuildType
	{
		// Token: 0x04000010 RID: 16
		ONEHANDER,
		// Token: 0x04000011 RID: 17
		TWOHANDER,
		// Token: 0x04000012 RID: 18
		POLEARM,
		// Token: 0x04000013 RID: 19
		ARCHER,
		// Token: 0x04000014 RID: 20
		THROWER
	}
}

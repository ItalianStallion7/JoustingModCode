﻿using System;

namespace LogRaamJousting
{
	// Token: 0x0200000D RID: 13
	public class JoustParticipant
	{
	}
}

﻿using System;

namespace LogRaamJousting.Equipments
{
	// Token: 0x02000032 RID: 50
	public enum ArmorTier
	{
		// Token: 0x04000067 RID: 103
		Soldier = 1,
		// Token: 0x04000068 RID: 104
		Wanderer,
		// Token: 0x04000069 RID: 105
		Lord,
		// Token: 0x0400006A RID: 106
		FactionLeader
	}
}

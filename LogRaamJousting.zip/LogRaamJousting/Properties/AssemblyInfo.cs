﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("LogRaamJousting")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("LogRaamJousting")]
[assembly: AssemblyCopyright("Copyright LogRaam©  2021")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("69a0fd28-f754-46dd-a1de-0b8582712dca")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[module: RefSafetyRules(11)]
